import React, { Component } from "react";
 
class Membership extends Component {
  render() {
    return (
      <div>
        <h2>Manage Membership</h2>
        <p>Manage Membership</p>
        <ol>
          <li>Redeem Points</li>
          <li>Transaction History</li>
          <li>Cancel Membership</li>
          <li>Questions</li>

        </ol>
      </div>
    );
  }
}
 
export default Membership;