import React, { Component } from "react";
 
class Contact extends Component {
  render() {
    return (
      <div>
        <h2>Transaction History</h2>
        <p>Past shipments shown below:

        </p>
      </div>
    );
  }
}
 
export default Contact;