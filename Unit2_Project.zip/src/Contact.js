import React, { Component } from "react";
 
class Contact extends Component {
  render() {
    return (
      <div>
        <h2>GOT QUESTIONS?</h2>
        <p>Send us a Message at: 

       <a href="https://lashify.com/pages/contact">Message concierge</a>.
       <p> Call us at: 800-555-5555</p>
        </p>
      </div>
    );
  }
}
 
export default Contact;