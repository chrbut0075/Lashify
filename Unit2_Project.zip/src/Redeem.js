import React, { Component } from "react";
 
class Redeem extends Component {
  render() {
    return (
      <div>
        <h2>Redeem Points</h2>
        <p>Your total available points to redeem are: 165
        </p>
      </div>
    );
  }
}
 
export default Redeem;