import React, { Component } from "react";
 
class Home extends Component {
  render() {
    return (
      <div>
        <h2>HELLO</h2>
        <p>Welcome Christina! This is your membership page.
          What would you like to do?
        </p>
        
        <p>Please select an option on the top menu.</p>
      </div>
    );
  }
}
 
export default Home;